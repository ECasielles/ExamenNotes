package com.example.usuario.notes.ui.base;

/**
 * Created by usuario on 12/14/17.
 */

public interface BasePresenter {
    void onDestroy();
}
